# Project Report: Residential Property Price Prediction

## Business objective
Develop a regression model that estimates the selling price of a residential property in lakhs of INR from property features, location, accessibility, amenities and related attributes.

## Dataset
The supplied CSV contains residential-property records and the target column `Price_Lakhs`. The dataset is included in `data/`. Check `reports/missing_values_report.csv` after running the training script for column-level missingness.

## Workflow
1. Inspect data shape, duplicates and missing values.
2. Remove duplicate rows and rows with a missing target.
3. Derive listing year and month from `Listing_Date`; remove `Property_ID`.
4. Split into training and test sets before fitting preprocessing.
5. Impute missing numeric values with the median and categorical values with the most frequent category.
6. Scale numeric variables and one-hot encode categorical variables using a `ColumnTransformer`.
7. Compare a median baseline, Linear Regression and Random Forest Regression.
8. Evaluate using MAE, RMSE and R².
9. Save the best pipeline, test predictions, IQR outlier report and VIF report.

## Why a pipeline?
A scikit-learn pipeline ensures that imputing, scaling and encoding are applied consistently during training and prediction. Fitting preprocessing only on the training split helps prevent test-data leakage.

## Metrics
- MAE: average absolute error in lakhs.
- RMSE: square-root of average squared error, in lakhs.
- R²: relative fit compared with predicting the target mean; values closer to 1 indicate stronger fit, but negative values are possible.

## Outliers and multicollinearity
The IQR report flags potentially unusual numeric observations for investigation. They are not removed automatically because extreme prices or areas may be legitimate. The VIF report can highlight correlated numeric predictors; interpret VIF alongside domain knowledge. Built-up and carpet area may be correlated.

## Conclusion
Run `python src/train.py` to produce actual model metrics. Report the measured values from `reports/model_metrics.csv` rather than inventing results. The model selected by the lowest held-out RMSE is saved as `models/property_price_pipeline.joblib`.

## Limitations
This educational dataset may not represent the full housing market. The model should not be used as a formal property valuation without independent validation, more representative data, and monitoring for market changes.
