from pathlib import Path
import pandas as pd
import joblib

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "models" / "property_price_pipeline.joblib"

def main():
    if not MODEL_PATH.exists():
        print("Model not found. Run this first: python src/train.py")
        return

    # Example only: replace values with a property you want to estimate.
    sample_property = {
        "City": "Pune",
        "Locality": "Wagholi",
        "Property_Type": "Apartment",
        "BHK": 2,
        "Built_Up_Area_sqft": 950.0,
        "Carpet_Area_sqft": 780.0,
        "Age_Years": 5.0,
        "Floor": "3",
        "Total_Floors": 10,
        "Bathrooms": 2,
        "Parking_Spaces": 1,
        "Furnishing_Status": "Semi-Furnished",
        "Facing": "East",
        "Gated_Community": "Yes",
        "Distance_to_Metro_km": 4.0,
        "Distance_to_CBD_km": 12.0,
        "Nearby_Schools": 3,
        "Crime_Index": 35.0,
        "Amenities_Score": 7.5,
        "Monthly_Maintenance_INR": 2500,
        "Seller_Type": "Owner",
        "Loan_Available": "Yes",
        "Annual_Property_Tax_INR": 30000,
        "Listing_Year": 2026,
        "Listing_Month": 10,
    }
    model = joblib.load(MODEL_PATH)
    prediction = float(model.predict(pd.DataFrame([sample_property]))[0])
    print(f"Estimated selling price: ₹{prediction:.2f} lakhs")
    print("Educational estimate only; verify against current local market data.")

if __name__ == "__main__":
    main()
