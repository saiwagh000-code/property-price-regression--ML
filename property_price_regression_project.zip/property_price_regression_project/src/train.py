from pathlib import Path
import json
import warnings

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
import joblib

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "ml_regression_property_dataset.csv"
MODEL_DIR = ROOT / "models"
REPORT_DIR = ROOT / "reports"
TARGET = "Price_Lakhs"
RANDOM_STATE = 42


def add_date_features(data: pd.DataFrame) -> pd.DataFrame:
    """Create date features without learning anything from the target."""
    data = data.copy()
    if "Listing_Date" in data.columns:
        dates = pd.to_datetime(data["Listing_Date"], errors="coerce")
        data["Listing_Year"] = dates.dt.year
        data["Listing_Month"] = dates.dt.month
        data = data.drop(columns=["Listing_Date"])
    # Identifier has no intended predictive meaning.
    data = data.drop(columns=["Property_ID"], errors="ignore")
    return data


def iqr_outlier_report(frame: pd.DataFrame) -> pd.DataFrame:
    """Report potential numeric outliers; do not delete them automatically."""
    rows = []
    numeric = frame.select_dtypes(include=np.number)
    for col in numeric.columns:
        q1, q3 = numeric[col].quantile([0.25, 0.75])
        iqr = q3 - q1
        low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        count = int(((numeric[col] < low) | (numeric[col] > high)).sum())
        rows.append({"feature": col, "lower_iqr_bound": low, "upper_iqr_bound": high,
                     "potential_outlier_count": count})
    return pd.DataFrame(rows)


def calculate_vif(frame: pd.DataFrame) -> pd.DataFrame:
    """Optional VIF diagnostic on numeric predictors; requires statsmodels."""
    try:
        from statsmodels.stats.outliers_influence import variance_inflation_factor
    except ImportError:
        return pd.DataFrame([{
            "note": "VIF skipped: install statsmodels (included in requirements.txt) to calculate it."
        }])

    numeric = frame.select_dtypes(include=np.number).replace([np.inf, -np.inf], np.nan)
    numeric = numeric.dropna(axis=1, how="all").fillna(numeric.median())
    # VIF needs variation; constant columns are not informative.
    numeric = numeric.loc[:, numeric.nunique(dropna=False) > 1]
    if numeric.shape[1] < 2:
        return pd.DataFrame([{"note": "Not enough numeric predictor columns to calculate VIF."}])
    # Sample to keep the diagnostic quick for larger datasets.
    numeric = numeric.sample(min(len(numeric), 2000), random_state=RANDOM_STATE) if len(numeric) > 2000 else numeric
    values = numeric.to_numpy(dtype=float)
    rows = []
    for i, col in enumerate(numeric.columns):
        try:
            vif = float(variance_inflation_factor(values, i))
        except Exception:
            vif = np.nan
        rows.append({"feature": col, "VIF": vif})
    return pd.DataFrame(rows).sort_values("VIF", ascending=False, na_position="last")


def build_preprocessor(X: pd.DataFrame) -> ColumnTransformer:
    numeric_cols = X.select_dtypes(include=np.number).columns.tolist()
    categorical_cols = X.select_dtypes(exclude=np.number).columns.tolist()

    numeric_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    categorical_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])
    return ColumnTransformer([
        ("numeric", numeric_pipeline, numeric_cols),
        ("categorical", categorical_pipeline, categorical_cols),
    ])


def main():
    if not DATA_PATH.exists():
        raise FileNotFoundError(f"Dataset not found: {DATA_PATH}")

    raw = pd.read_csv(DATA_PATH)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    MODEL_DIR.mkdir(parents=True, exist_ok=True)

    # Initial data-quality report.
    quality = pd.DataFrame({
        "column": raw.columns,
        "missing_count": [int(raw[c].isna().sum()) for c in raw.columns],
        "missing_percent": [round(float(raw[c].isna().mean() * 100), 2) for c in raw.columns],
    })
    quality.to_csv(REPORT_DIR / "missing_values_report.csv", index=False)
    (REPORT_DIR / "data_quality_summary.txt").write_text(
        f"Rows: {len(raw)}\nColumns: {len(raw.columns)}\n"
        f"Duplicate rows: {int(raw.duplicated().sum())}\n"
        f"Target missing values: {int(raw[TARGET].isna().sum()) if TARGET in raw else 'target missing'}\n",
        encoding="utf-8"
    )

    if TARGET not in raw.columns:
        raise ValueError(f"Target column '{TARGET}' is not present.")
    raw = raw.drop_duplicates()
    raw = raw.dropna(subset=[TARGET])
    y = raw[TARGET].astype(float)
    X = add_date_features(raw.drop(columns=[TARGET]))

    # Diagnostics are descriptive only; no observations are automatically removed as outliers.
    outlier_data = add_date_features(raw.drop(columns=[TARGET]))
    iqr_outlier_report(outlier_data).to_csv(REPORT_DIR / "iqr_outlier_report.csv", index=False)
    calculate_vif(outlier_data).to_csv(REPORT_DIR / "vif_report.csv", index=False)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=RANDOM_STATE
    )

    candidates = {
        "DummyMedian": DummyRegressor(strategy="median"),
        "LinearRegression": LinearRegression(),
        "RandomForest": RandomForestRegressor(
            n_estimators=300, min_samples_leaf=2, random_state=RANDOM_STATE, n_jobs=-1
        ),
    }

    results = []
    fitted = {}
    for name, estimator in candidates.items():
        pipe = Pipeline([
            ("preprocessor", build_preprocessor(X_train)),
            ("model", estimator),
        ])
        pipe.fit(X_train, y_train)
        predictions = pipe.predict(X_test)
        results.append({
            "model": name,
            "MAE_Lakhs": float(mean_absolute_error(y_test, predictions)),
            "RMSE_Lakhs": float(np.sqrt(mean_squared_error(y_test, predictions))),
            "R2": float(r2_score(y_test, predictions)),
        })
        fitted[name] = pipe

    metrics = pd.DataFrame(results).sort_values("RMSE_Lakhs")
    metrics.to_csv(REPORT_DIR / "model_metrics.csv", index=False)
    best_name = str(metrics.iloc[0]["model"])
    best_model = fitted[best_name]
    joblib.dump(best_model, MODEL_DIR / "property_price_pipeline.joblib")

    pred = best_model.predict(X_test)
    pd.DataFrame({
        "Actual_Price_Lakhs": y_test.to_numpy(),
        "Predicted_Price_Lakhs": pred,
        "Residual_Lakhs": y_test.to_numpy() - pred,
    }).to_csv(REPORT_DIR / "test_predictions.csv", index=False)

    summary = {
        "target": TARGET,
        "rows_used": int(len(raw)),
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "best_model_by_test_RMSE": best_name,
        "metrics": metrics.to_dict(orient="records"),
        "random_state": RANDOM_STATE,
    }
    (REPORT_DIR / "training_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print("\nModel comparison (price values are in lakhs of INR):")
    print(metrics.to_string(index=False, float_format=lambda x: f"{x:.3f}"))
    print(f"\nBest model by test RMSE: {best_name}")
    print(f"Saved pipeline: {MODEL_DIR / 'property_price_pipeline.joblib'}")
    print(f"Reports saved in: {REPORT_DIR}")


if __name__ == "__main__":
    main()
