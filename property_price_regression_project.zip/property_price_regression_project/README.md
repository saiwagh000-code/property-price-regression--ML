# Residential Property Price Prediction (Regression)

## 1. Project overview
This project builds a machine-learning regression model to predict the **selling price of a residential property in lakhs of INR** from property characteristics, location, accessibility, amenities, and market-related attributes.

- **Business objective:** Estimate residential property prices to support preliminary pricing and market analysis.
- **Learning objective:** Clean imperfect data, explore patterns, engineer useful features, compare regression models, assess outliers and multicollinearity, and package preprocessing with the model in a reusable pipeline.
- **Target column:** `Price_Lakhs`
- **Dataset:** `data/ml_regression_property_dataset.csv` (provided with this project)

> This is an educational model trained on the supplied dataset. Predictions are estimates, not official valuations or financial advice.

## 2. Project structure
```text
property_price_regression_project/
├── data/
│   └── ml_regression_property_dataset.csv
├── reports/
│   └── project_report.md
├── models/                      # created after training
├── src/
│   ├── train.py
│   └── predict.py
├── .gitignore
├── requirements.txt
└── README.md
```

## 3. Features and target
The dataset contains property details such as city/locality, property type, BHK, area, age, floor, bathrooms, parking, furnishing, metro/CBD distance, nearby schools, crime index, amenities score, maintenance, seller type, loan availability and annual property tax. The target is `Price_Lakhs`.

`Property_ID` is an identifier and is excluded from training. `Listing_Date` is converted to date-derived features (listing year and month) and the original date is removed. Missing numerical values are filled using the training-set median; missing categorical values are filled using the most frequent category. Categorical columns are one-hot encoded, and numerical columns are standardized, all inside a scikit-learn pipeline to reduce data leakage.

## 4. How to run (Windows)
Open Command Prompt or the VS Code terminal inside this folder.

### Step 1 — create a virtual environment (recommended)
```bash
python -m venv .venv
.venv\Scripts\activate
```

### Step 2 — install libraries
```bash
pip install -r requirements.txt
```

### Step 3 — train and evaluate
```bash
python src/train.py
```

The script creates a `models/` folder containing the fitted pipeline and writes evaluation metrics and diagnostic outputs to `reports/`.

### Step 4 — predict a property price
After training:
```bash
python src/predict.py
```
Edit the example property dictionary in `src/predict.py` to try different values.

## 5. Evaluation
The script compares:
- **Dummy Regressor:** baseline that predicts the training target median.
- **Linear Regression:** interpretable linear baseline.
- **Random Forest Regressor:** nonlinear tree-ensemble model.

Metrics:
- **MAE (Mean Absolute Error):** average absolute prediction error, in lakhs.
- **RMSE (Root Mean Squared Error):** penalizes larger errors more strongly, in lakhs.
- **R²:** proportion of target variance explained by the model; can be negative if performance is worse than a constant baseline.

The best model is selected by the lowest test-set RMSE. Results depend on the supplied dataset and split seed. Do not claim a model is accurate until you have run the script and reviewed the output.

## 6. Data quality and analysis
The training script:
- reports missing values and duplicate rows;
- parses listing dates and derives year/month;
- splits data before fitting imputers, encoders, or scalers;
- reports extreme values using the IQR rule for numeric columns (diagnostic only; observations are not automatically deleted);
- calculates VIF for selected numeric predictors when the optional `statsmodels` dependency is available;
- evaluates models on a held-out test set;
- saves actual-versus-predicted values and residuals for review.

**Multicollinearity note:** Built-up area and carpet area may be strongly related. VIF is a diagnostic, not an automatic instruction to remove a feature. Tree-based models are less sensitive to multicollinearity than coefficient-based linear regression.

## 7. GitHub upload
1. Sign in to GitHub and create a new **public or private repository** named `property-price-regression`.
2. Extract this ZIP file.
3. Open the extracted project folder.
4. In GitHub, use **Add file → Upload files**, then drag the project files/folders into the page and commit. For large folders, or if you prefer a local workflow, use Git commands:
```bash
git init
git add .
git commit -m "Add residential property price regression project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/property-price-regression.git
git push -u origin main
```
Replace `YOUR-USERNAME` with your GitHub username. Run these commands from the project folder after creating the empty GitHub repository. Do not upload `.venv/` or private credentials.

## 8. Suggested project summary for your mentor
“I built a residential property price prediction project using regression. I cleaned missing values through a reusable preprocessing pipeline, converted the listing date into useful features, encoded categorical variables, and compared a baseline model, Linear Regression, and Random Forest. I evaluated the models using MAE, RMSE, and R² on a held-out test set. I also included outlier and multicollinearity diagnostics and saved the fitted pipeline so the same preprocessing is applied when making predictions.”

## 9. Limitations and responsible use
- The model learns patterns only from the supplied data; dataset representativeness and real-world validity are not guaranteed.
- Locality and city patterns can shift over time.
- A good test score does not prove that the model is suitable for real estate transactions.
- Validate with more recent, verified market data before any real-world use.
